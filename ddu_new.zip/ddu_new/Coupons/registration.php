<?php
/*
 * Copyright (c) 2021. CueBlocks Technologies
 * @author: Sumit
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'CueBlocks_Coupons',
    __DIR__);
