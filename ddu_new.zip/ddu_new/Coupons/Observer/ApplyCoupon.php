<?php
/*
 * Copyright (c) 2021. CueBlocks Technologies
 * @author: Sumit
 */

namespace CueBlocks\Coupons\Observer;

use Magento\Checkout\Model\Cart as CustomerCart;
use Magento\Checkout\Model\Session;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Message\ManagerInterface;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\SalesRule\Model\CouponFactory;
use Magento\SalesRule\Model\RuleFactory;
use Magento\Store\Model\ScopeInterface;

class ApplyCoupon implements ObserverInterface
{
    const XML_ENABLED = 'cb_coupon/general/enable';
    const XML_SUBSCRIBER_ENABLED = 'cb_coupon/general/subscriber_only';
    /**
     * @var ManagerInterface
     */
    protected $messageManager;
    /**
     * @var Session
     */
    protected $checkoutSession;
    /**
     * @var CustomerSession
     */
    protected $customerSession;
    /**
     * @var CustomerCart
     */
    protected $cart;
    /**
     * @var CartRepositoryInterface
     */
    protected $quoteRepository;
    /**
     * @var CouponFactory
     */
    protected $couponFactory;
    /**
     * @var RuleFactory
     */
    protected $ruleFactory;
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;
    /**
     * @var SubscriberFactory
     */
    private $subscriberFactory;

    /**
     * ApplyCoupon constructor.
     * @param ManagerInterface $messageManager
     * @param Session $checkoutSession
     * @param CustomerSession $customerSession
     * @param CustomerCart $cart
     * @param CouponFactory $couponFactory
     * @param RuleFactory $ruleFactory
     * @param CartRepositoryInterface $quoteRepository
     * @param ScopeConfigInterface $scopeConfig
     * @param SubscriberFactory $subscriberFactory
     */
    public function __construct(
        ManagerInterface $messageManager,
        Session $checkoutSession,
        CustomerSession $customerSession,
        CustomerCart $cart,
        CouponFactory $couponFactory,
        RuleFactory $ruleFactory,
        CartRepositoryInterface $quoteRepository,
        ScopeConfigInterface $scopeConfig,
        SubscriberFactory $subscriberFactory
    ) {
        $this->messageManager = $messageManager;
        $this->checkoutSession = $checkoutSession;
        $this->customerSession = $customerSession;
        $this->cart = $cart;
        $this->couponFactory = $couponFactory;
        $this->ruleFactory = $ruleFactory;
        $this->quoteRepository = $quoteRepository;
        $this->scopeConfig = $scopeConfig;
        $this->subscriberFactory = $subscriberFactory;
    }

    /**
     * @param Observer $observer
     * @return false|void
     */
    public function execute(Observer $observer)
    {
        $enabled = $this->scopeConfig->getValue(self::XML_ENABLED, ScopeInterface::SCOPE_STORE);
        if ($enabled && $this->customerSession->getCouponErrorMessage()) {
            $this->messageManager->addErrorMessage($this->customerSession->getCouponErrorMessage());
            $this->customerSession->unsCouponErrorMessage();
            return false;
        }
        if ($enabled && $this->checkCustomerAccount()) {
            $this->applyCoupon();
        }
    }

    /**
     * Apply Coupon Function
     */
    public function applyCoupon()
    {
        $couponCode = (string)$this->customerSession->getCouponCode();
        if (!empty($couponCode)) {
            $cartQuote = $this->cart->getQuote();
            $oldCouponCode = $cartQuote->getCouponCode();
            if (!$oldCouponCode) {
                $this->_applyCoupon($couponCode, $cartQuote);
            } else {
                $newDiscountAmount = $this->_discountAmount($couponCode, $cartQuote);
                $oldDiscountAmount = $this->_discountAmount($oldCouponCode, $cartQuote);
                if ($newDiscountAmount && $oldDiscountAmount && ($newDiscountAmount > $oldDiscountAmount)) {
                    $this->_applyCoupon($couponCode, $cartQuote);
                }
            }
            if ($cartQuote->getSubtotal() !== $cartQuote->getSubtotalWithDiscount()) {
                $this->messageManager->addSuccessMessage("The newsletter discount is applied to your cart!");
            } else {
                $this->messageManager->addWarningMessage("The newsletter discount is not applied to your cart!");
            }
            $this->customerSession->unsCouponCode();
        }
    }

    /**
     * @param $couponCode
     * @param $cartQuote
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function _applyCoupon($couponCode, $cartQuote)
    {
        $cartQuote->getShippingAddress()->setCollectShippingRates(true);
        $cartQuote->setCouponCode(strlen($couponCode) ? $couponCode : '');
        $this->checkoutSession->getQuote()->setCouponCode(strlen($couponCode) ? $couponCode : '')->save();
        $this->quoteRepository->save($cartQuote->collectTotals());
    }

    /**
     * @param $couponCode
     * @param $cartQuote
     * @return float|int|null
     */
    protected function _discountAmount($couponCode, $cartQuote)
    {
        $coupon = $this->couponFactory->create();
        if ($coupon) {
            $coupon->load($couponCode, 'code');
            $rule = $this->ruleFactory->create();
            if ($rule) {
                $rule->load($coupon->getRuleId());
                if ($rule->getSimpleAction() == 'by_percent') {
                    return ($cartQuote->getSubtotal() * $rule->getDiscountAmount()) / 100;
                } elseif ($rule->getSimpleAction() == 'by_fixed' || $rule->getSimpleAction() == 'cart_fixed') {
                    return $rule->getDiscountAmount();
                }
            }
        }
        return null;
    }

    /**
     * @return bool
     */
    protected function checkCustomerAccount()
    {
        $subscriberOnly = $this->scopeConfig->getValue(self::XML_SUBSCRIBER_ENABLED, ScopeInterface::SCOPE_STORE);
        if (!$subscriberOnly && $this->customerSession->isLoggedIn()) {
            return true;
        }
        if ($subscriberOnly && $this->customerSession->isLoggedIn()) {
            return (bool)$this->subscriberFactory->create()->loadByCustomerId($this->customerSession->getCustomerId())->isSubscribed();
        }
        return false;
    }
}