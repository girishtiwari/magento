<?php
/*
 * Copyright (c) 2021. CueBlocks Technologies
 * @author: Sumit
 */

namespace CueBlocks\Coupons\Observer;

use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\ScopeInterface;

class CheckCoupon implements ObserverInterface
{
    const XML_ENABLED = 'cb_coupon/general/enable';
    const XML_COUPON_CODE = 'cb_coupon/general/coupon_code';
    /**
     * @var CustomerSession
     */
    protected $customerSession;
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * CheckCoupon constructor.
     * @param CustomerSession $customerSession
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        CustomerSession $customerSession,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->customerSession = $customerSession;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $enabled = $this->scopeConfig->getValue(self::XML_ENABLED, ScopeInterface::SCOPE_STORE);
        $xmlCouponCode = $this->scopeConfig->getValue(self::XML_COUPON_CODE, ScopeInterface::SCOPE_STORE);
        if ($enabled && trim($xmlCouponCode)) {
            $couponCode = $observer->getEvent()->getRequest()->getParam('coupon_code');
            if ($couponCode == $xmlCouponCode) {
                $observer->getEvent()->getRequest()->setParam('coupon_code', '');
                $this->customerSession->setCouponErrorMessage("The coupon code '$couponCode' is not valid.");
            }
        }
    }
}