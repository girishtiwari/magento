<?php
/*
 * Copyright (c) 2021. CueBlocks Technologies
 * @author: Sumit
 */

namespace CueBlocks\Coupons\Plugin;

use Magento\Customer\Controller\Account\Login;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Message\ManagerInterface;
use Magento\Store\Model\ScopeInterface;

class LoginAction
{
    const XML_ENABLED = 'cb_coupon/general/enable';
    /**
     * @var Session
     */
    protected $customerSession;
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;
    /**
     * @var ManagerInterface
     */
    protected $messageManager;

    /**
     * Login constructor.
     * @param Session $customerSession
     * @param ScopeConfigInterface $scopeConfig
     * @param ManagerInterface $messageManager
     */
    public function __construct(
        Session $customerSession,
        ScopeConfigInterface $scopeConfig,
        ManagerInterface $messageManager
    ) {
        $this->customerSession = $customerSession;
        $this->scopeConfig = $scopeConfig;
        $this->messageManager = $messageManager;
    }

    /**
     * @param Login $subject
     * @param $result
     * @return mixed
     */
    public function afterExecute(Login $subject, $result)
    {
        $enabled = $this->scopeConfig->getValue(self::XML_ENABLED, ScopeInterface::SCOPE_STORE);
        if (!$enabled) {
            return $result;
        }
        $coupon = $subject->getRequest()->getParam('coupon_code');
        if (!empty($coupon)) {
            $this->customerSession->setCouponCode($coupon);
            if (!$this->customerSession->isLoggedIn()) {
                $this->messageManager->addWarningMessage("Please login to apply the newsletter discount!");
            } else {
                $this->messageManager->addWarningMessage("Please add product(s) to your cart and go to the cart page to check the newsletter discount eligibility");
            }
        }
        return $result;
    }
}